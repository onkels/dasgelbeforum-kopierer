package internetkopierer.dgf;
import internetkopierer.BeitragsNummer;

import java.io.File;
import org.apache.log4j.Logger;

public class FuelleLuecken {

	public static Logger logger = Logger.getLogger(FuelleLuecken.class);
	
	public static void main(String[] args) {
		logger.info("start");
		fuelleLuecken(Integer.valueOf(args[0]), args[1]);
		logger.info("ende");
	}
	
	
	public static void fuelleLuecken(int startBeitrag, String zielVerzeichnis) {
		DGFFeedReader dgfFeedReader = new DGFFeedReader();
		String neuesterBeitrag = dgfFeedReader.holeNeuesteBeitragsId();
		
		DGFBeitragArchivierer dgfBeitragArchivierer = new DGFBeitragArchivierer(zielVerzeichnis);
		for (int i=startBeitrag; i<=Integer.valueOf(neuesterBeitrag); i++) {
	// for (int i=startBeitrag; i<=5000; i++) {		
			try {
				String unterOrdner = BeitragsNummer.erzeugeVerzeichnisNummer(String.valueOf(i));
				
				File datei = new File(zielVerzeichnis + unterOrdner + "/" + String.valueOf(i) + ".html");
				if (!datei.exists()) {
//					System.out.println("Lücke " + i);
					dgfBeitragArchivierer.archiviereBeitrag(String.valueOf(i));
				}
			}
			catch (Throwable t) {
				logger.error(t.getMessage(), t);
			}
		}
	}
	
}
