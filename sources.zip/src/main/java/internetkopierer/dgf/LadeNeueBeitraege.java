package internetkopierer.dgf;

import java.io.File;
import org.apache.log4j.Logger;

/**		
Historische Beiträge laden, um Lücken zu füllen -> eine Seite pro Beitrag
Neuere Beiträge laden, falls System down (eine Seite pro Beitrag)
Aktuelle Beiträge laden, d.h. auf neue Beiträge warten -> Frameset

Neue Beiträge laden
	Zunächst die höchste lokal gespeicherte Beitragsnummer feststellen
	Danach die aktuelle höchste Beitragsnummer aus dem Feed ermitteln
	Alle Beiträge dazwischen laden, als Einzeldatei
	Danach in FrameSet-Modus wechseln 
	
Aktuelle Beiträge laden
	Alle 5 Minuten den Feed auf neue Beiträge prüfen
	Wenn neue Beiträge, für diese ein FrameSet anlegen und die aktuelle Version laden.
	Die FrameSet-Datei hat den Namen des Beitrags, d.h. 222333.html (damit die Verlinkung klappt)
	Die Dateinamen der Versionen sind BeitragsNummer_1 _2 _3.html 

	Hier ein Beispiel für das Frameset
		
		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN"
   		"http://www.w3.org/TR/html4/frameset.dtd">
		<html>
		<head>
		<title>222025</title>
		</head>
		<frameset cols="33%,33%,33%">
	  	<frame src="222025_1.html">
	  	<frame src="222025_2.html">
	  	<frame src="222025_3.html">
		</frameset>
		</html>

		Es werden 3 Versionen geladen: sofort, nach 30 Minuten und nach 60 Minuten.
		Nachdem die erste Version geladen ist, wird die BeitragsID+Zeitstempel in eine LinkedList eingetragen.
		
		Danach wird überprüft, ob in der LinkedList Beiträge sind, die vor mehr als 30 Minuten eingestellt worden sind.
		Falls ja, werden diese aus der LinkedList entfernt und die Version _2.html der Beiträge geladen.
		War dies erfolgreich, werden die BeitragsIds und Zeitstempel in eine weitere LinkedList eingetragen.
		
		Daraus werden dann nach einer Stunde analog die Version _3 geladen.			
*/
public class LadeNeueBeitraege {
	
	public static Logger logger = Logger.getLogger(LadeNeueBeitraege.class);
	
	public static void main(String[] args) {
		logger.info("start");
		new LadeAktuelleBeitraege().ladeAktuelleBeitraege(args[0]);
		logger.info("ende");
	}
	
	public int ladeNeueBeitraege(String zielVerzeichnis) {
/*		Zunächst die höchste lokal gespeicherte Beitragsnummer feststellen
		Danach die aktuelle höchste Beitragsnummer aus dem Feed ermitteln
		Alle Beiträge dazwischen laden, als Einzeldatei
		Danach in FrameSet-Modus wechseln
*/		 
		// Zunächst die höchste lokal gespeicherte Beitragsnummer feststellen
		int nummerDesNeuestenArchiviertenBeitrags = -1;
		File[] files = new File(zielVerzeichnis).listFiles();
		if (files != null) {
			int hoechstesVerzeichnis = -1;
			for (File file : files) {
				if (file.isDirectory()) {
					try {
						int verzeichnis = Integer.parseInt(file.getName());
						hoechstesVerzeichnis = Math.max(verzeichnis, hoechstesVerzeichnis);
					}
					catch (Throwable t) {
						t.printStackTrace();
					}
				}
			}
			
			// es gibt lokal gespeicherte Dateien
			if (hoechstesVerzeichnis > -1) {
				files = new File(zielVerzeichnis + "/" + Integer.toString(hoechstesVerzeichnis) + "/").listFiles();
				if (files != null) {

					for (File file : files) {
						if (file.isFile()) {
							try {
								// ermittle das erste nicht numerische Zeichen im Namen, d.h.
								// entweder der .html oder _1.html bei Framesets
								String fileName = file.getName();
								int index = fileName.indexOf("_");
								if (index == -1) {
									index = fileName.indexOf(".");
								}
								String beitragsNummerString = fileName.substring(0, index);

								int beitragsNummer = Integer.parseInt(beitragsNummerString);
								nummerDesNeuestenArchiviertenBeitrags = Math.max(beitragsNummer, nummerDesNeuestenArchiviertenBeitrags);
							}
							catch (Throwable t) {
								t.printStackTrace();
							}
						}
					}
				}
			}
		}
		
		logger.info(nummerDesNeuestenArchiviertenBeitrags);
		
		// Danach die aktuelle höchste Beitragsnummer aus dem Feed ermitteln
		String beitragsNummer = DGFFeedReader.holeNeuesteBeitragsId();
		logger.info(beitragsNummer);	

		if (beitragsNummer != null) {
			
			DGFBeitragArchivierer dgfBeitragArchivierer = new DGFBeitragArchivierer(zielVerzeichnis);
			
			int hoechsteBeitragsNummer = Integer.parseInt(beitragsNummer);
			
			for (int i=nummerDesNeuestenArchiviertenBeitrags+1; i<=hoechsteBeitragsNummer; i++) {
				dgfBeitragArchivierer.archiviereBeitrag(String.valueOf(i));
			}
			
			return hoechsteBeitragsNummer;
		}
		else {
			return nummerDesNeuestenArchiviertenBeitrags;
		}
	}
	
}
