package internetkopierer.dgf;
import internetkopierer.Bild;
import internetkopierer.DateiSchreiber;

import org.apache.log4j.Logger;

public class DGFBeitragArchivierer {

	private String zielVerzeichnis = null;
	
	private DateiSchreiber dgfDateiSchreiber = null;
	
	public DGFBeitragArchivierer(String zielVerzeichnis) {
		super();
		this.zielVerzeichnis = zielVerzeichnis;
		dgfDateiSchreiber = new DateiSchreiber(zielVerzeichnis);
	}

	public static Logger logger = Logger.getLogger(DGFBeitragArchivierer.class);
	
	
	private void archiviereBeitrag(String beitragsNummer, String dateiName) {
		
		logger.info("archiviere " + beitragsNummer);

		String beitrag = DGFBeitragLeser.holeBeitrag(beitragsNummer);
		if (beitrag != null) {
			
			// Bilder speichern
			int bilderIndex = 0;
			
			while (bilderIndex > -1) {
				bilderIndex = beitrag.indexOf("<img src=", bilderIndex);
				
				if (bilderIndex > -1) {
					try {
						int bildUrlAnfang = beitrag.indexOf("\"", bilderIndex) + 1;
						int bildUrlEnde = beitrag.indexOf("\"", bildUrlAnfang);
						
						String bildURL = beitrag.substring(bildUrlAnfang, bildUrlEnde);
						if (bildURL.startsWith("http")) {

							String unterOrdner = dgfDateiSchreiber.erzeugeUnterOrdner(beitragsNummer);
							
							Bild bild = new Bild();
							
							bild.ladeBild(bildURL, zielVerzeichnis + unterOrdner + "/img/");
							if (bild.isGeladen()) {
								beitrag = beitrag.replaceAll(bildURL, "img/" + bild.getDateiName());							
							}
						}
					}
					catch (Throwable t) {
						logger.error(t.getMessage(), t);
					}
					bilderIndex++;
				}
			}
			
			dgfDateiSchreiber.schreibeDatei(beitragsNummer, dateiName, beitrag);	
		}
	}

	public void archiviereBeitrag(String beitragsNummer) {
		archiviereBeitrag(beitragsNummer, beitragsNummer + ".html");
	}
	
	public void archiviereBeitragFrameset(String beitragsNummer, String version) {
		archiviereBeitrag(beitragsNummer, beitragsNummer + "_" + version + ".html");
	}
} 
