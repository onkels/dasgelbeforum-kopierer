package internetkopierer.dgf;
import internetkopierer.DateiSchreiber;
import internetkopierer.WartelistenEintrag;

import java.util.Date;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import org.apache.log4j.Logger;

/**		
Historische Beiträge laden, um Lücken zu füllen -> eine Seite pro Beitrag
Neuere Beiträge laden, falls System down (eine Seite pro Beitrag)
Aktuelle Beiträge laden, d.h. auf neue Beiträge warten -> Frameset

Neue Beiträge laden
	Zunächst die höchste lokal gespeicherte Beitragsnummer feststellen
	Danach die aktuelle höchste Beitragsnummer aus dem Feed ermitteln
	Alle Beiträge dazwischen laden, als Einzeldatei
	Danach in FrameSet-Modus wechseln 
	
Aktuelle Beiträge laden
	Alle 5 Minuten den Feed auf neue Beiträge prüfen
	Wenn neue Beiträge, für diese ein FrameSet anlegen und die aktuelle Version laden.
	Die FrameSet-Datei hat den Namen des Beitrags, d.h. 222333.html (damit die Verlinkung klappt)
	Die Dateinamen der Versionen sind BeitragsNummer_1 _2 _3.html 

	Hier ein Beispiel für das Frameset
		
		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN"
   		"http://www.w3.org/TR/html4/frameset.dtd">
		<html>
		<head>
		<title>222025</title>
		</head>
		<frameset cols="33%,33%,33%">
	  	<frame src="222025_1.html">
	  	<frame src="222025_2.html">
	  	<frame src="222025_3.html">
		</frameset>
		</html>

		Es werden 3 Versionen geladen: sofort, nach 30 Minuten und nach 60 Minuten.
		Nachdem die erste Version geladen ist, wird die BeitragsID+Zeitstempel in eine LinkedList eingetragen.
		
		Danach wird überprüft, ob in der LinkedList Beiträge sind, die vor mehr als 30 Minuten eingestellt worden sind.
		Falls ja, werden diese aus der LinkedList entfernt und die Version _2.html der Beiträge geladen.
		War dies erfolgreich, werden die BeitragsIds und Zeitstempel in eine weitere LinkedList eingetragen.
		
		Daraus werden dann nach einer Stunde analog die Version _3 geladen.			
*/
public class LadeAktuelleBeitraege {
	
	public static Logger logger = Logger.getLogger(LadeAktuelleBeitraege.class);
	
	public static void main(String[] args) {
		logger.info("start");
		new LadeAktuelleBeitraege().ladeAktuelleBeitraege(args[0]);
		logger.info("ende");
	}
	
	public void ladeAktuelleBeitraege(String zielVerzeichnis) {
		
		// neue Beiträge 2 mal laden
		int letzerArchivierterBeitrag = 0;
		
		for (int i=0;i<2;i++) {
			letzerArchivierterBeitrag = new LadeNeueBeitraege().ladeNeueBeitraege(zielVerzeichnis);	
		}
		
		DateiSchreiber dgfDateiSchreiber = new DateiSchreiber(zielVerzeichnis);
		DGFBeitragArchivierer dgfBeitragArchivierer = new DGFBeitragArchivierer(zielVerzeichnis);
		
		List<WartelistenEintrag> warteListe1 = new LinkedList<WartelistenEintrag>();
		List<WartelistenEintrag> warteListe2 = new LinkedList<WartelistenEintrag>();
		
		while (true) {
			try {
				logger.info("schlafe ...");
				Thread.sleep(300000);
				
				int neuesterBeitrag = Integer.parseInt(DGFFeedReader.holeNeuesteBeitragsId()); 
				
				// Framesets anlegen
				for (int i=letzerArchivierterBeitrag+1; i<=neuesterBeitrag; i++) {
					String beitragsNummer = String.valueOf(i);
					
					String inhalt = "		<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Frameset//EN\"" + 
			   		"\"http://www.w3.org/TR/html4/frameset.dtd\">" +
					"<html><head><title>BEITRAG</title></head>" +
					"<frameset cols=\"33%,33%,33%\">" +
					"<frame src=\"BEITRAG_1.html\">" +
				  	"<frame src=\"BEITRAG_2.html\">" +
				  	"<frame src=\"BEITRAG_3.html\">" +
					"</frameset></html>";

					logger.info("erzeuge FrameSet für " + beitragsNummer);
					dgfDateiSchreiber.schreibeDatei(beitragsNummer, beitragsNummer + ".html", inhalt.replaceAll("BEITRAG", beitragsNummer));
					
					// Version _1 archivieren
					dgfBeitragArchivierer.archiviereBeitragFrameset(beitragsNummer, "1");
					
					// in Warteliste für erste Aktualisierung einstellen
					logger.info(" Liste 1 ADD " + beitragsNummer);
					
					warteListe1.add(new WartelistenEintrag(beitragsNummer, new Date()));
				}
				
				letzerArchivierterBeitrag = neuesterBeitrag;
			
				// Prüfen auf Updates nach 30 Minuten
				for (Iterator<WartelistenEintrag> iterator = warteListe1.iterator(); iterator.hasNext();) {
					WartelistenEintrag wartelistenEintrag = iterator.next();
					
					if (wartelistenEintrag.getZeitpunkt().getTime() + 1800000 < System.currentTimeMillis()) {
						// Version _2 archivieren
						dgfBeitragArchivierer.archiviereBeitragFrameset(wartelistenEintrag.getBeitragsNummer(), "2");

						logger.info(" Liste 2 ADD " + wartelistenEintrag.getBeitragsNummer());
						warteListe2.add(wartelistenEintrag);
							
						logger.info(" Liste 1 SUB " + wartelistenEintrag.getBeitragsNummer());
						iterator.remove();
					}
				}
				
				
				// Prüfen auf Updates nach 60 Minuten
				for (Iterator<WartelistenEintrag> iterator = warteListe2.iterator(); iterator.hasNext();) {
					WartelistenEintrag wartelistenEintrag = iterator.next();
					if (wartelistenEintrag.getZeitpunkt().getTime() + 3600000 < System.currentTimeMillis()) {

						// Version _3 archivieren
						dgfBeitragArchivierer.archiviereBeitragFrameset(wartelistenEintrag.getBeitragsNummer(), "3");
						
						logger.info(" Liste 2 SUB " + wartelistenEintrag.getBeitragsNummer());
						iterator.remove();
					}
				}
				
				String liste1 = "";
				for (WartelistenEintrag eintrag : warteListe1) {
					liste1 = liste1 + eintrag.getBeitragsNummer() + ",";
				}
				logger.info("Liste 1: " + liste1);
				
				String liste2 = "";
				for (WartelistenEintrag eintrag : warteListe2) {
					liste2 = liste2 + eintrag.getBeitragsNummer() + ",";
				}
				logger.info("Liste 2: " + liste2);
			}
			catch (Throwable t) {
				logger.error(t.getMessage(), t);
			}
		}
	}
	
}
