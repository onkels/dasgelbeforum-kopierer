package internetkopierer.dgf;

import java.util.Random;
import org.apache.log4j.Logger;
/**		
Historische Beiträge laden, um Lücken zu füllen -> eine Seite pro Beitrag
Neuere Beiträge laden, falls System down (eine Seite pro Beitrag)
Aktuelle Beiträge laden, d.h. auf neue Beiträge warten -> Frameset


Neue Beiträge laden
	Zunächst die höchste lokal gespeicherte Beitragsnummer feststellen
	Danach die aktuelle höchste Beitragsnummer aus dem Feed ermitteln
	Alle Beiträge dazwischen laden, als Einzeldatei
	Danach in FrameSet-Modus wechseln 
	
Aktuelle Beiträge laden
	Alle 5 Minuten den Feed auf neue Beiträge prüfen
	Wenn neue Beiträge, für diese ein FrameSet anlegen und die aktuelle Version laden.
	Die FrameSet-Datei hat den Namen des Beitrags, d.h. 222333.html (damit die Verlinkung klappt)
	Die Dateinamen der Versionen sind BeitragsNummer_1 _2 _3.html 

	Hier ein Beispiel für das Frameset
		
		<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Frameset//EN"
   		"http://www.w3.org/TR/html4/frameset.dtd">
		<html>
		<head>
		<title>222025</title>
		</head>
		<frameset cols="33%,33%,33%">
	  	<frame src="222025_1.html">
	  	<frame src="222025_2.html">
	  	<frame src="222025_3.html">
		</frameset>
		</html>

		Es werden 3 Versionen geladen: sofort, nach 30 Minuten und nach 60 Minuten.
		Nachdem die erste Version geladen ist, wird die BeitragsID+Zeitstempel in eine LinkedList eingetragen.
		
		Danach wird überprüft, ob in der LinkedList Beiträge sind, die vor mehr als 30 Minuten eingestellt worden sind.
		Falls ja, werden diese aus der LinkedList entfernt und die Version _2.html der Beiträge geladen.
		War dies erfolgreich, werden die BeitragsIds und Zeitstempel in eine weitere LinkedList eingetragen.
		
		Daraus werden dann nach einer Stunde analog die Version _3 geladen.			
*/
public class LadeAlteBeitraege {

	public static Logger logger = Logger.getLogger(LadeAlteBeitraege.class);
	
	public static void main(String[] args) {
		logger.info("start");
		ladeAlteBeitraege(Integer.valueOf(args[0]), args[1], args.length>2);
		logger.info("ende");
	}
	
	
	public static void ladeAlteBeitraege(int startBeitrag, String zielVerzeichnis, boolean mitPause) {
		Random random = new Random();
		int anzahl=random.nextInt(200) + 50;
		
		if (mitPause) {
			logger.info("lade " + anzahl + " Beiträge");	
		}
		
		DGFBeitragArchivierer dgfBeitragArchivierer = new DGFBeitragArchivierer(zielVerzeichnis);
		for (int i=startBeitrag; i<=220000; i++) {
			try {
				if (mitPause) {
					anzahl--;
					if (anzahl == 0) {
						logger.info("schlafe");
						try {
							Thread.sleep(random.nextInt(360000));
						}
						catch (Throwable t) {
							logger.error(t.getMessage(), t);
						}
						anzahl = random.nextInt(200) + 50; 
						logger.info("lade " + anzahl + " Beiträge");
					}
				}
				dgfBeitragArchivierer.archiviereBeitrag(String.valueOf(i));
			}
			catch (Throwable t) {
				logger.error(t.getMessage(), t);
			}
		}
	}
	
}
