package internetkopierer.dgf;
import internetkopierer.BeitragsNummer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;

public class DGFBeitragLeser {
	
	private static Logger logger = Logger.getLogger(DGFBeitragLeser.class);
	
    public static String holeBeitrag(String beitragsId) {
    	
        HttpClient client = new HttpClient();
        HttpMethod method = new GetMethod("http://www.dasgelbeforum.net/forum_entry.php?id=" + beitragsId);

        try {
        	method.setFollowRedirects(false);
            client.executeMethod(method);
            
            logger.info(method.getStatusCode() + " " + beitragsId);
            
            if (method.getStatusCode() == HttpStatus.SC_OK) {
            	
            	StringBuffer beitrag = new StringBuffer();
                
                BufferedReader rd = new BufferedReader(new InputStreamReader(method.getResponseBodyAsStream()));

                String line;
                             
                while ((line = rd.readLine()) != null) {
                	while (line.indexOf("href=\"forum_entry.php?id=") > 0) {
                		int index0 = line.indexOf("href=\"forum_entry.php?id=");
                		int index1 = index0 + "href=\"forum_entry.php?id=".length();
                		int index2 = line.indexOf("\"", index1);
                		String beitragsNummerZiel = line.substring(index1, index2);
                		line = line.substring(0, index0) + "href=\"../" + BeitragsNummer.erzeugeVerzeichnisNummer(beitragsNummerZiel) + "/" + beitragsNummerZiel + ".html\" target=\"_parent" + line.substring(index2);
                	}
                	beitrag.append(line);
                }
                
                return beitrag.toString();
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        } finally {
            method.releaseConnection();
        }
        return null;
    }
}
