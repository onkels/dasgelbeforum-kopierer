package internetkopierer.dgf;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;

public class DGFFeedReader {
	
	private static Logger logger = Logger.getLogger(DGFFeedReader.class);
	
    public static String holeNeuesteBeitragsId() {

        HttpMethod method = null;

        try {
            method = new GetMethod("http://www.dasgelbeforum.net/rss.php");
        	HttpClient client = new HttpClient();
        	client.executeMethod(method);
            
            if (method.getStatusCode() == HttpStatus.SC_OK) {
                
                BufferedReader rd = new BufferedReader(new InputStreamReader(method.getResponseBodyAsStream()));

                String line;
                
                while ((line = rd.readLine()) != null) {
                	
                	if (line.startsWith("<link>") && line.indexOf("id=")>0) {
                		String beitragsNo = line.substring(line.indexOf("?id=")+4, line.indexOf("</link>")); 
                		logger.info(beitragsNo + " " + line);
                		return beitragsNo;
                	}
                }
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        } finally {
        	if (method != null) {
        		method.releaseConnection();	
        	}
        }
        return null;
    }
}
