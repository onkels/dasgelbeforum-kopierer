package internetkopierer;
import java.io.*;

import org.apache.log4j.Logger;
 
public class DateiSchreiber {
	
	private static Logger logger = Logger.getLogger(DateiSchreiber.class);
	
	private String zielVerzeichnis = null; 
	
    public DateiSchreiber(String zielVerzeichnis) {
		super();
		this.zielVerzeichnis = zielVerzeichnis;
	}

	public void schreibeDatei(String beitragsNummer, String dateiName, String inhalt) {
    	
    	FileWriter out = null;
    	try {
    		String unterOrdner = erzeugeUnterOrdner(beitragsNummer);
    		String dateiPfad = zielVerzeichnis + unterOrdner + "/" + dateiName;
        	File outputFile = new File(dateiPfad); // beitragsNummer + ".html");
        	logger.info("schreibe " + dateiPfad); 
            out = new FileWriter(outputFile);
            out.write(inhalt);
    	}
    	catch (Throwable t) {
    		logger.error(t.getMessage(),t);
    	}
    	finally {
    		if (out != null) {
    			try {
    				out.close();	
    			}
    			catch (Throwable t) {
    	    		logger.error(t.getMessage(),t);
    			}
    		}
    	}
    }
    
    public String erzeugeUnterOrdner(String beitragsNummer) {
    	String unterOrdnerName = BeitragsNummer.erzeugeVerzeichnisNummer(beitragsNummer);
		File f = new File(zielVerzeichnis + unterOrdnerName);
		if (!f.isDirectory()) {
			f.mkdir();
			File f2 = new File(zielVerzeichnis + unterOrdnerName + "/img");
			f2.mkdir();
		}
		return unterOrdnerName;
   	}
    
}