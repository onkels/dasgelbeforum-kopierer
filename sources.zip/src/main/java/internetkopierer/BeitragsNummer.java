package internetkopierer;

public class BeitragsNummer {

	public static String erzeugeVerzeichnisNummer(String beitragsNummer) {
		
		if (beitragsNummer == null) {
			return null;
		}
		
		Integer verzeichnisNo = null;
		
		try {
			verzeichnisNo = Integer.parseInt(beitragsNummer)/1000;
		}
		catch (NumberFormatException e) {
			System.out.println(beitragsNummer + " " + e.getMessage());
		}
		
		return String.valueOf(verzeichnisNo);
	}
}
