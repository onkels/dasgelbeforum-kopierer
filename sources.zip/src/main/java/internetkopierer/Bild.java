package internetkopierer;
import java.io.FileOutputStream;
import java.io.OutputStream;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;
public class Bild {

	Logger logger = Logger.getLogger(Bild.class);
	
	private String dateiName;
	
	private boolean geladen = false;
	
	public void ladeBild(String bildURL, String zielVerzeichnis) {
    	HttpMethod method = null;
    	OutputStream out = null;
        try {
        	HttpClient client = new HttpClient();
        	client.setTimeout(10000);
        	client.getParams().setSoTimeout(10000);
        	client.getParams().setConnectionManagerTimeout(10000);
        	
        	method = new GetMethod(bildURL);
        	method.setFollowRedirects(true);

        	
        	client.executeMethod(method);
        	logger.info("ladeBild " + method.getStatusCode() + " " + bildURL);
        	if (method.getStatusCode() == HttpStatus.SC_OK) {
        		byte[] daten = method.getResponseBody();
        		     		
        		dateiName =  bildURL.toLowerCase().replaceAll("[^A-Za-z0-9+-]", "");
        		if (dateiName.length() > 254) {
        			dateiName = dateiName.substring(dateiName.length()-254);
        		}

        		if (dateiName.endsWith("jpg")) {
        			dateiName = dateiName.substring(0, dateiName.length()-3) + ".jpg";
        		}
        		if (dateiName.endsWith("jpeg")) {
        			dateiName = dateiName.substring(0, dateiName.length()-3) + ".jpeg";
        		}
        		if (dateiName.endsWith("gif")) {
        			dateiName = dateiName.substring(0, dateiName.length()-3) + ".gif";
        		}
        		if (dateiName.endsWith("bmp")) {
        			dateiName = dateiName.substring(0, dateiName.length()-3) + ".bmp";
        		}
        		if (dateiName.endsWith("png")) {
        			dateiName = dateiName.substring(0, dateiName.length()-3) + ".png";
        		}
        		
                out = new FileOutputStream(zielVerzeichnis + dateiName);
                out.write(daten);
                out.close();

                geladen = true;
        	}
        } catch (Throwable t) {
			logger.error(t.getMessage(), t);
        } finally {
        	if (out != null) {
        		try {
        			out.close();	
        		}
        		catch (Throwable t) {
        			logger.error(t.getMessage(), t);
        		}
        	}
        	if (method != null) {
        		method.releaseConnection();	
        	}
        }
	}
	
	
	public boolean isGeladen() {
		return geladen;
	}
	
	public String getDateiName() {
		return dateiName;
	}
	

}
