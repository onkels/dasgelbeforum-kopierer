package internetkopierer;
import java.util.Date;


public class WartelistenEintrag {

	private String 	beitragsNummer;
	private Date 	zeitpunkt;
	
	public WartelistenEintrag(String beitragsNummer, Date zeitpunkt) {
		super();
		this.beitragsNummer = beitragsNummer;
		this.zeitpunkt = zeitpunkt;
	}
	
	public String getBeitragsNummer() {
		return beitragsNummer;
	}

	public Date getZeitpunkt() {
		return zeitpunkt;
	}
	
}
