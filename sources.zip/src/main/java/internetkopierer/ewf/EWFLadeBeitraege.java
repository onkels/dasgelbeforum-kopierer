package internetkopierer.ewf;
import org.apache.log4j.Logger;

public class EWFLadeBeitraege {

	public static Logger logger = Logger.getLogger(EWFLadeBeitraege.class);
	
	public static void main(String[] args) {
		logger.info("start");
		ladeBeitraege(Integer.valueOf(args[0]), args[1]);
		logger.info("ende");
	}
	
	
	public static void ladeBeitraege(int startBeitrag, String zielVerzeichnis) {
		EWFBeitragArchivierer ewfBeitragArchivierer = new EWFBeitragArchivierer(zielVerzeichnis);
		for (int i=startBeitrag; i<=400000; i++) {
			try {
				ewfBeitragArchivierer.archiviereBeitrag(String.valueOf(i));
			}
			catch (Throwable t) {
				logger.error(t.getMessage(), t);
			}
		}
	}
	
}
