package internetkopierer.ewf;
import internetkopierer.Bild;
import internetkopierer.DateiSchreiber;

import org.apache.log4j.Logger;

public class EWFBeitragArchivierer {

	private String zielVerzeichnis = null;
	
	private DateiSchreiber dgfDateiSchreiber = null;
	private EWFBeitragLeser ewfBeitragLeser = null;
	
	public EWFBeitragArchivierer(String zielVerzeichnis) {
		super();
		this.zielVerzeichnis = zielVerzeichnis;
		dgfDateiSchreiber = new DateiSchreiber(zielVerzeichnis);
		ewfBeitragLeser = new EWFBeitragLeser();
	}

	public static Logger logger = Logger.getLogger(EWFBeitragArchivierer.class);
	
	public void archiviereBeitrag(String beitragsNummer) {
	
		logger.info("archiviere EWF " + beitragsNummer);

		String beitrag = ewfBeitragLeser.holeBeitrag(beitragsNummer);
		if (beitrag != null) {
			
			// Bilder speichern
			int bilderIndex = 0;
			
			while (bilderIndex > -1) {
				bilderIndex = beitrag.indexOf("<img src=", bilderIndex);
				
				if (bilderIndex > -1) {
					try {
						int bildUrlAnfang = beitrag.indexOf("\"", bilderIndex) + 1;
						int bildUrlEnde = beitrag.indexOf("\"", bildUrlAnfang);
						
						String bildURL = beitrag.substring(bildUrlAnfang, bildUrlEnde);
						if (bildURL.startsWith("http")) {

							String unterOrdner = dgfDateiSchreiber.erzeugeUnterOrdner(beitragsNummer);
							
							Bild bild = new Bild();
							
							bild.ladeBild(bildURL, zielVerzeichnis + unterOrdner + "/img/");
							if (bild.isGeladen()) {
								beitrag = beitrag.replaceAll(bildURL, "img/" + bild.getDateiName());							
							}
						}
					}
					catch (Throwable t) {
						logger.error(t.getMessage(), t);
					}
					bilderIndex++;
				}
			}
			
			dgfDateiSchreiber.schreibeDatei(beitragsNummer, beitragsNummer + ".htm", beitrag);	
		}
	}

} 
