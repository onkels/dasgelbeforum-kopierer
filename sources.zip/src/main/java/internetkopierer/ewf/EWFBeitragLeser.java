package internetkopierer.ewf;
import internetkopierer.BeitragsNummer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.log4j.Logger;

public class EWFBeitragLeser {
	
	private static Logger logger = Logger.getLogger(EWFBeitragLeser.class);
	
    public String holeBeitrag(String beitragsId) {
    	
        HttpClient client = new HttpClient();
        HttpMethod method = new GetMethod("http://dasgelbeforum.de.org/30434/messages/" + beitragsId + ".htm");

        try {
        	method.setFollowRedirects(false);
            client.executeMethod(method);
            
            logger.info(method.getStatusCode() + " " + beitragsId);
            
            if (method.getStatusCode() == HttpStatus.SC_OK) {
            	
            	StringBuffer beitrag = new StringBuffer();
                
                BufferedReader rd = new BufferedReader(new InputStreamReader(method.getResponseBodyAsStream(), "CP1250"));

                String line;
                             
                while ((line = rd.readLine()) != null) {
                	
                	if (line.indexOf("<head>") > 0) {
                		line = line + "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=\"UTF-8\">";
                	}
                	
                	line = line.replaceAll("�", "&auml;").replaceAll("�", "&Auml;").
                				replaceAll("�", "&ouml;").replaceAll("�", "&Ouml;").
                				replaceAll("�", "&uuml;").replaceAll("�", "&Uuml;").
                				replaceAll("�", "&szlig;");
                	
                	for (int i=0; i<10; i++) {
                		String suchmaske = "<a href=\"" + String.valueOf(i);
                    	if (line.indexOf(suchmaske) > 0) {
                    		int index0 = line.indexOf(suchmaske);
                    		int index1 = index0 + suchmaske.length();
                    		int index2 = line.indexOf(".htm\">", index1);
                    		int index3 = line.indexOf("=", index1);
                    		if (index2 > 0) {
                    			
                    			String beitragsNummerZiel = line.substring(index1-1, index2);
                    			// hack f�r kaputte Beitr�ge
                    			if (index3 > 0 && index3 < index2) {
                    				beitragsNummerZiel = line.substring(index3+2, index2);
                    			}
                    			
                        		try {
                        			int zielNummer = Integer.parseInt(beitragsNummerZiel);
                        			line = line.substring(0, index0) + "<a href=\"../" + BeitragsNummer.erzeugeVerzeichnisNummer(beitragsNummerZiel) + "/" + beitragsNummerZiel + line.substring(index2);
                        		}
                    			catch (Throwable t) {
//                    				logger.error(t.getMessage(), t);
                    				System.out.println(beitragsId + " " + beitragsNummerZiel + " " + line);
                    			}
                    		}
                    	}
                	}
                	beitrag.append(line);
                }
                
                return beitrag.toString();
            }
        } catch (IOException e) {
            logger.error(e.getMessage(), e);
        } finally {
            method.releaseConnection();
        }
        return null;
    }
    
    public static void main(String[] args) {
		System.out.println(new EWFBeitragLeser().holeBeitrag("398865"));
	}
}
